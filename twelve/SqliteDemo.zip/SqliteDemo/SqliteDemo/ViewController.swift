//
//  ViewController.swift
//  SqliteDemo
//
//  Created by liguiyang on 2018/12/5.
//  Copyright © 2018年 yls. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfPhone: UITextField!
    @IBOutlet weak var tfNo: UITextField!
    let db = SQLiteDB.shared
    override func viewDidLoad() {
        super.viewDidLoad()
        let result = db.open(dbPath: "", copyFile: true)
        print("result:\(result)")
        let r = db.execute(sql: "create table if not exists student1(stuName varchar(20),stuNo varchar(20),stuPhone varchar(20)))")
        print("result:\(r)")
        print(NSHomeDirectory())
        print(Bundle.main.bundlePath)
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func add(_ sender: Any) {
        let result = db.execute(sql: "insert into student1(stuName,stuNo,stuPhone) values('\(tfName.text!)','\(tfNo.text!)','\(tfPhone.text!)')")
        print("result:\(result)")
        
    }
    @IBAction func udpate(_ sender: Any) {
        let result = db.execute(sql: "update student1 set stuPhone ='\(tfPhone.text!)' and  stuNo ='\(tfNo.text!)' where stuName = '\(tfName.text!)'")
        print("result:\(result)")
   }
    @IBAction func del(_ sender: Any) {
        let result = db.execute(sql: "delete from student1 where stuName = '\(tfName.text!)'")
        print("result:\(result)")
    }
    
    @IBAction func query(_ sender: Any) {
        let persons = db.query(sql: "select * from student1 where stuName = '\(tfName.text!)'")
        if let person = persons.first {
            tfPhone.text = person["stuPhone"] as? String
        }
    }
}

