//
//  student.swift
//  moreMVC1
//
//  Created by student on 2018/12/6.
//  Copyright © 2018年 yuanlinshuang. All rights reserved.
//

import Foundation

class student {
    var no = ""
    var name = ""
}
